package com.guangdian.networkassistant;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView state;
    private final int bg = Color.rgb(8, 15, 30);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 24);
        root.setBackgroundColor(bg);

        TextView title = new TextView(this);
        title.setText("广电网络优化助手 PRO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 8);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("本地 DNS 优化 VPN · 仅接管 DNS 请求");
        desc.setTextColor(Color.rgb(0, 190, 255));
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, 0, 0, 24);
        root.addView(desc);

        state = new TextView(this);
        state.setText("状态：尚未启动\nDNS：自动选择较快的公共解析器");
        state.setTextColor(Color.WHITE);
        state.setTextSize(16);
        state.setPadding(16, 20, 16, 20);
        state.setBackgroundColor(Color.rgb(20, 34, 57));
        root.addView(state);

        Button start = button("启动 DNS 优化");
        root.addView(start);
        start.setOnClickListener(v -> {
            Intent request = VpnService.prepare(this);
            if (request != null) startActivityForResult(request, 100);
            else startVpn();
        });

        Button stop = button("停止优化");
        root.addView(stop);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, DnsVpnService.class));
            state.setText("状态：已停止\n手机将恢复使用系统默认 DNS 路径。");
        });

        Button settings = button("打开网络设置");
        root.addView(settings);
        settings.setOnClickListener(v ->
            startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)));

        TextView warning = new TextView(this);
        warning.setText("\n工作方式：只将发往虚拟 DNS 地址的 IPv4 DNS 查询转发到公共 DNS（优先 1.1.1.1，备用 8.8.8.8）。其他网络流量不进入 VPN。\n\n注意：DNS 优化可能改善域名解析响应，但不能提高基站信号、突破运营商限速或保证降低游戏延迟。");
        warning.setTextColor(Color.LTGRAY);
        warning.setTextSize(12);
        warning.setPadding(4, 18, 4, 0);
        root.addView(warning);

        setContentView(root);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(15, 95, 160)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58);
        p.setMargins(0, 10, 0, 4);
        b.setLayoutParams(p);
        return b;
    }

    private void startVpn() {
        Intent i = new Intent(this, DnsVpnService.class);
        i.setAction(DnsVpnService.ACTION_START);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        state.setText("状态：正在启动 DNS 优化 VPN…\n请观察系统 VPN 图标。");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) startVpn();
        else if (requestCode == 100) state.setText("状态：未获得 VPN 授权");
    }
}
