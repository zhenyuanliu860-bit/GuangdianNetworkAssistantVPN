package com.guangdian.networkassistant;

import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.os.Build;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public class DnsVpnService extends VpnService {
    public static final String ACTION_START = "com.guangdian.networkassistant.START";
    private static final String TAG = "DnsVpnService";
    private static final String CHANNEL = "dns_optimizer";
    private static final byte[] VIRTUAL_DNS = {(byte)10, 10, 0, 1};
    private ParcelFileDescriptor tun;
    private Thread worker;
    private final AtomicBoolean running = new AtomicBoolean(false);

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(7, notification());
        if (intent != null && ACTION_START.equals(intent.getAction())) startTunnel();
        return START_STICKY;
    }

    private void startTunnel() {
        if (running.get()) return;
        try {
            Builder builder = new Builder();
            builder.setSession("广电网络 DNS 优化");
            builder.addAddress("10.10.0.2", 32);
            builder.addDnsServer("10.10.0.1");
            builder.addRoute("10.10.0.1", 32);
            builder.setMtu(1500);
            if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false);
            tun = builder.establish();
            if (tun == null) throw new IllegalStateException("VPN 建立失败");
            running.set(true);
            worker = new Thread(this::packetLoop, "dns-vpn-worker");
            worker.start();
        } catch (Exception e) {
            Log.e(TAG, "Unable to start VPN", e);
            stopSelf();
        }
    }

    private void packetLoop() {
        byte[] packet = new byte[32767];
        try (FileInputStream in = new FileInputStream(tun.getFileDescriptor());
             FileOutputStream out = new FileOutputStream(tun.getFileDescriptor())) {
            while (running.get()) {
                int length = in.read(packet);
                if (length <= 0) continue;
                byte[] response = handleDnsPacket(packet, length);
                if (response != null) out.write(response);
            }
        } catch (Exception e) {
            if (running.get()) Log.e(TAG, "VPN packet loop failed", e);
        } finally {
            running.set(false);
            stopSelf();
        }
    }

    private byte[] handleDnsPacket(byte[] p, int len) {
        try {
            if (len < 28 || (p[0] >> 4 & 0x0f) != 4 || (p[9] & 0xff) != 17) return null;
            int ihl = (p[0] & 0x0f) * 4;
            if (len < ihl + 8) return null;
            int dstPort = u16(p, ihl + 2);
            if (dstPort != 53) return null;
            if (p[ihl + 4] == 0 && p[ihl + 5] == 0) return null;

            int dnsLen = u16(p, ihl + 4) - 8;
            if (dnsLen < 12 || ihl + 8 + dnsLen > len) return null;
            byte[] query = new byte[dnsLen];
            System.arraycopy(p, ihl + 8, query, 0, dnsLen);

            byte[] answer = forwardDns(query);
            if (answer == null) return null;
            return buildIpv4UdpResponse(p, ihl, answer);
        } catch (Exception e) {
            Log.w(TAG, "Dropped malformed packet", e);
            return null;
        }
    }

    private byte[] forwardDns(byte[] query) {
        String[] servers = {"1.1.1.1", "8.8.8.8"};
        for (String server : servers) {
            try (DatagramSocket socket = new DatagramSocket()) {
                if (!protect(socket)) continue;
                socket.setSoTimeout(2500);
                byte[] address = InetAddress.getByName(server).getAddress();
                DatagramPacket request = new DatagramPacket(query, query.length,
                    InetAddress.getByAddress(address), 53);
                socket.send(request);
                byte[] buffer = new byte[4096];
                DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
                socket.receive(reply);
                byte[] result = new byte[reply.getLength()];
                System.arraycopy(reply.getData(), reply.getOffset(), result, 0, result.length);
                return result;
            } catch (SocketTimeoutException e) {
                Log.w(TAG, "DNS timeout at " + server);
            } catch (Exception e) {
                Log.w(TAG, "DNS error at " + server, e);
            }
        }
        return null;
    }

    private byte[] buildIpv4UdpResponse(byte[] request, int ihl, byte[] dns) {
        int total = 20 + 8 + dns.length;
        byte[] r = new byte[total];
        r[0] = 0x45;
        r[1] = 0;
        put16(r, 2, total);
        put16(r, 4, 0);
        put16(r, 6, 0x4000);
        r[8] = 64;
        r[9] = 17;
        // Swap source and destination IPv4 addresses.
        System.arraycopy(request, 16, r, 12, 4);
        System.arraycopy(request, 12, r, 16, 4);
        put16(r, 10, checksum(r, 0, 20));
        put16(r, 20, 53);
        put16(r, 22, u16(request, ihl));
        put16(r, 24, 8 + dns.length);
        System.arraycopy(dns, 0, r, 28, dns.length);
        return r;
    }

    private int checksum(byte[] b, int off, int len) {
        long sum = 0;
        for (int i = off; i < off + len; i += 2) {
            int hi = b[i] & 0xff;
            int lo = i + 1 < off + len ? b[i + 1] & 0xff : 0;
            sum += (hi << 8) | lo;
        }
        while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
        return (int)(~sum) & 0xffff;
    }

    private int u16(byte[] b, int i) {
        return ((b[i] & 0xff) << 8) | (b[i + 1] & 0xff);
    }

    private void put16(byte[] b, int i, int v) {
        b[i] = (byte)(v >> 8);
        b[i + 1] = (byte)v;
    }

    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);
        return b.setContentTitle("广电网络优化助手")
            .setContentText("DNS 优化服务正在运行")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                CHANNEL, "DNS 优化服务", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        running.set(false);
        try { if (tun != null) tun.close(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
